﻿package ar.org.centro8.java.curso.entities.enums;

public enum NombreTutor {
    Paoletti_María_Eleonora,
    Sagarna_Valeria,
    Sánchez_Roberto_Esteban;
}
