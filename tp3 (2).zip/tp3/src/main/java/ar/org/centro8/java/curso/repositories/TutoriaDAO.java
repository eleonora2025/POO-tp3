package ar.org.centro8.java.curso.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.java.curso.entities.Tutoria;
import ar.org.centro8.java.curso.entities.enums.Genero;
import ar.org.centro8.java.curso.entities.enums.Nacionalidad;
import ar.org.centro8.java.curso.entities.enums.NivelEducativo;
import ar.org.centro8.java.curso.entities.enums.NombreTutor;
import ar.org.centro8.java.curso.entities.enums.ProvinciaDeResidencia;
import ar.org.centro8.java.curso.repositories.interfaces.ITutoriaDAO;

@Repository
public class TutoriaDAO implements ITutoriaDAO {

    private final DataSource dataSource;

    private static final String SQL_CREATE = "INSERT INTO Tutoria (apellido_nombre, cuit, genero, provincia_residencia, edad, nacionalidad, nivel_educativo, nombre_tutor) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM Tutoria WHERE id=?";
    private static final String SQL_FIND_ALL = "SELECT * FROM Tutoria";
    private static final String SQL_UPDATE = "UPDATE Tutoria SET apellido_nombre=?, cuit=?, genero=?, provincia_residencia=?, edad=?, nacionalidad=?, nivel_educativo=?, nombre_tutor=? WHERE id=?";
    private static final String SQL_DELETE = "DELETE FROM Tutoria WHERE id=?";
    private static final String SQL_FIND_BY_EMPRESA = "SELECT * FROM Tutoria WHERE id_empresa = ?";

    // private static final String SQL_FIND_BY_EMPRESA =
    // "SELECT t.* FROM Tutoria t " +
    // "JOIN Evaluacion e ON t.id = e.id_tutoria " +
    // "WHERE e.id_empresa = ?";

    private static final String SQL_FIND_BY_EVALUACION = "SELECT * FROM Tutoria WHERE id_evaluaciona=?";

    public TutoriaDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Tutoria tutoria) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, tutoria.getApellidoNombre());
            ps.setString(2, tutoria.getCuit());
            ps.setString(3, tutoria.getGenero().name());
            ps.setString(4, tutoria.getProvinciaDeResidencia().name());
            ps.setInt(5, tutoria.getEdad());
            ps.setString(6, tutoria.getNacionalidad().name());
            ps.setString(7, tutoria.getNivelEducativo().name());
            ps.setString(8, tutoria.getNombreTutor().name());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    tutoria.setId(keys.getInt(1));
                }
            }
        }
    }

    private Tutoria mapRow(ResultSet rs) throws SQLException {
        Tutoria t = new Tutoria();

        t.setId(rs.getInt("id"));
        t.setApellidoNombre(rs.getString("apellido_nombre"));
        t.setCuit(rs.getString("cuit"));

        // Los enums se obtienen como texto desde la BD y se convierten con valueOf
        t.setGenero(Genero.valueOf(rs.getString("genero")));
        t.setProvinciaDeResidencia(ProvinciaDeResidencia.valueOf(rs.getString("provincia_residencia")));
        t.setEdad(rs.getInt("edad"));
        t.setNacionalidad(Nacionalidad.valueOf(rs.getString("nacionalidad")));
        t.setNivelEducativo(NivelEducativo.valueOf(rs.getString("nivel_educativo")));
        t.setNombreTutor(NombreTutor.valueOf(rs.getString("nombre_tutor")));

        return t;
    }

    @Override
    public Tutoria findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }

        return null; // si no se encontró la tutoría con ese id
    }

    @Override
    public List<Tutoria> findAll() throws SQLException {
        List<Tutoria> tutorias = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                tutorias.add(mapRow(rs));
            }
        }

        return tutorias;
    }

    @Override
    public int update(Tutoria tutoria) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {

            ps.setString(1, tutoria.getApellidoNombre());
            ps.setString(2, tutoria.getCuit());
            ps.setString(3, tutoria.getGenero().name());
            ps.setString(4, tutoria.getProvinciaDeResidencia().name());
            ps.setInt(5, tutoria.getEdad());
            ps.setString(6, tutoria.getNacionalidad().name());
            ps.setString(7, tutoria.getNivelEducativo().name());
            ps.setString(8, tutoria.getNombreTutor().name());
            ps.setInt(9, tutoria.getId());

            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Tutoria> findByEmpresa(int idEmpresa) throws SQLException {
        List<Tutoria> tutorias = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_EMPRESA)) {

            ps.setInt(1, idEmpresa);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    tutorias.add(mapRow(rs));
                }
            }
        }

        return tutorias;
    }

    // @Override
    // public List<Tutoria> findByEmpresa(int idEmpresa) throws SQLException {
    // List<Tutoria> tutorias = new ArrayList<>();
    //
    // try (Connection conn = dataSource.getConnection();
    // PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_EMPRESA)) {
    //
    // ps.setInt(1, idEmpresa);
    //
    // try (ResultSet rs = ps.executeQuery()) {
    // while (rs.next()) {
    // tutorias.add(mapRow(rs));
    // }
    // }
    // }
    //
    // return tutorias;
    // }

    @Override
    public List<Tutoria> findByEvaluacion(int idEvaluacion) throws SQLException {
        List<Tutoria> tutorias = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_EVALUACION)) {

            ps.setInt(1, idEvaluacion);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    tutorias.add(mapRow(rs));
                }
            }
        }

        return tutorias;
    }

}