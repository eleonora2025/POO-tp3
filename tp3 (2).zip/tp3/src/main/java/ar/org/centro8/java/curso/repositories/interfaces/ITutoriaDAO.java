package ar.org.centro8.java.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;
import ar.org.centro8.java.curso.entities.Tutoria;

public interface ITutoriaDAO {

    /**
     * Método para crear una tutoría. Recibe como parámetro un objeto del tipo
     * Tutoria y guarda el registro en la base de datos.
     * 
     * @param turoria -> recibe un objeto de tutoría al que luego le setea el id
     *                autogenerado por la base
     * @throws SQLException
     */
    void create(Tutoria tutoria) throws SQLException;

    /**
     * Método que busca una tutoría por su id. Recibe como parámetro el id de la
     * tutoria a buscar y lo retorna como un objeto de la clase Tutoria.
     * 
     * @param id
     * @return
     * @throws SQLException
     */
    Tutoria findById(int id) throws SQLException;

    /**
     * Método para obtener el listado de todas las tutorías. No recibe parámetros y
     * devuelve una lista de todos los registros de tutorías en la base de datos.
     * 
     * @return
     * @throws SQLException
     */
    List<Tutoria> findAll() throws SQLException;

    /**
     * Método para actualizar una tutoría en la base de datos. Recibe como parámetro
     * un objeto del tipo Tutoria y actualiza sus datos en el registro de la base de
     * datos.
     * 
     * @param tutoria
     * @return
     * @throws SQLException
     */
    int update(Tutoria tutoria) throws SQLException;

    /**
     * Método para eliminar una tutoría en la base de datos. Recibe como parámetro
     * un id que identifica la tutoría. Devuelve un entero indicando si se pudo
     * eliminar el registro.
     * 
     * @param id
     * @return
     * @throws SQLException
     */
    int delete(int id) throws SQLException;

    /**
     * Método que busca tutorías por su id de evaluación. Recibe como parámetro el
     * id de la evaluación y devuelve una lista con todos los registros de las
     * tutorías.
     * 
     * @param idEvaluacion
     * @return
     * @throws SQLException
     */
    List<Tutoria> findByEvaluacion(int idEvaluacion) throws SQLException;

    /**
     * Método que busca tutorías por su id de empresa. Recibe como parámetro el id
     * de la empresa y devuelve una lista con todos los registros de las tutorías.
     * 
     * @param idEmpresa
     * @return
     * @throws SQLException
     */
    List<Tutoria> findByEmpresa(int idEmpresa) throws SQLException;
}
