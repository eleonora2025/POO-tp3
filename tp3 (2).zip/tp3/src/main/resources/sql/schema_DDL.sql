﻿drop database if exists dcc1;
create database dcc1;
use dcc1;

drop table if exists tutorias;
drop table if exists empresas;
drop table if exists evaluaciones;

create table tutorias (
    id int auto_increment primary key,
    apellido_nombre varchar (100) not null,
    CUIT char(11),
    provincia_residencia enum ('CABA', 'Buenos Aires', 'Córdoba', 'Misiones', 'Río Negro', 'Entre Ríos'),
    edad int (99),
    nacionalidad enum ('Argentina', 'Boliviana','Paraguaya', 'Venezolana'),
    genero enum ('Masculino', 'Femenino'),
    nivel_educativo enum ('Primaria Incompleta', 'Primaria Completa', 'Secundaria Incompleta', 'Secundaria Completa', 'Terciario Incompleto', 'Terciario Completo', 'Universitario Incompleto', 'Universitario Completo'),
    nombre_tutor enum ('Paoletti, María Eleonora', 'Sagarna, Valeria', 'Sánchez, Roberto Esteban')
);

create table empresas (
    id int auto_increment primary key,
    nombre_empresa varchar(100) not null,
    CUIT_empresa char(11)
);

create table evaluaciones (
    id int auto_increment primary key,
    id_tutorias int,
    id_empresas int, 
    fecha_evaluacion date not null,
    provincia_evaluacion enum ('CABA', 'Buenos Aires', 'Córdoba', 'Misiones', 'Corrientes', 'Río Negro', 'San Luis', 'Entre Ríos'),
    norma_evaluada enum ('Albañil', 'Armador de H°A°', 'Carpintero de H°A°', 'Auxiliar General'),
    resultado enum ('Competente', 'Aún No Competente','No Certificar'),
    nombre_evaluador enum ('Mazzei, María Cecilia', 'Domínguez, Martín Erasmo', 'Montenegro, Ramiro'),        
    foreign key (id_tutorias) references tutorias(id),
    foreign key (id_empresas) references empresas(id)
);


