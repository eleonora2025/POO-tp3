package ar.org.centro8.java.curso.entities.enums;

public enum NivelEducativo {
    Primaria_Incompleta,
    Primaria_Completa,
    Secundaria_Incompleta,
    Secundaria_Completa,
    Terciario_Incompleto,
    Terciario_Completo,
    Universitario_Incompleto,
    Universitario_Completo;

}
