﻿package ar.org.centro8.java.curso.entities.enums;

public enum ProvinciaDeResidencia {
    CABA,
    Buenos_Aires,
    Córdoba,
    Misiones,
    Corrientes,
    Río_Negro,
    La_Pampa,
    San_Luis,
    Santa_Fe,
    Santiago_del_Estero,
    Entre_Ríos;



}
