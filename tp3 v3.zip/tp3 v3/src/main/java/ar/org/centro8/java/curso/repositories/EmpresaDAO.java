﻿package ar.org.centro8.java.curso.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.java.curso.entities.Empresa;
import ar.org.centro8.java.curso.repositories.interfaces.IEmpresaDAO;

@Repository
public class EmpresaDAO implements IEmpresaDAO {

    // creamos un objeto de DataSource que nos permite obtener la conexión a la base
    // de datos.

    private final DataSource dataSource;

    private static final String SQL_CREATE = "INSERT INTO Empresa (nombre_empresa, CUIT_empresa) VALUES (?, ?)";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM Empresa WHERE id=?";
    private static final String SQL_FIND_ALL = "SELECT * FROM Empresa";
    private static final String SQL_UPDATE = "UPDATE Empresa SET nombre_empresa=?, CUIT_empresa=? WHERE id=?";
    private static final String SQL_DELETE = "DELETE FROM Empresa WHERE id=?";
    private static final String SQL_FIND_BY_EVALUACION = "SELECT * FROM Empresa WHERE id_evaluacion=?";
    private static final String SQL_FIND_BY_TUTORIA = "SELECT * FROM Empresa WHERE id_tutoria = ?";

    public EmpresaDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    // de esta manera el repositorio queda configurado con la fuente de conexiones
    // que usará siempre el repositorio no crea su propio datasource, si no que se
    // le proporciona uno configurado Con HikariCP.

    @Override
    public void create(Empresa empresa) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, empresa.getNombreEmpresa());
            ps.setString(2, empresa.getCuit());

            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    empresa.setId(keys.getInt(1));
                }
            }
        }
    }

    // Otra versión create
    //@Override
     //public void create(Empresa empresa) throws SQLException {
        //try (Connection conn = dataSource.getConnection();
            //PreparedStatement ps = conn.prepareStatement(SQL_CREATE,Statement.RETURN_GENERATED_KEYS)) {
    
        //ps.setString(1, empresa.getNombreEmpresa());
        //ps.setString(2, empresa.getCuit());
    
        //int rows = ps.executeUpdate();
            //if (rows == 0) { //------>>(IF)si no se insertó ninguna empresa
            //throw new SQLException("No se insertó ninguna empresa");
        //}
    
        //try (ResultSet keys = ps.getGeneratedKeys()) {
            //if (keys.next()) {
            //empresa.setId(keys.getInt(1));     //---> asigna el ID generado a la empresa
                //} else { //si no se generó ID, entonces ELSE
                //throw new SQLException("No se generó ID para empresa");
            //}
        //}
     //}

    //} 

    private Empresa mapRow(ResultSet rs) throws SQLException {
        Empresa e = new Empresa();
        e.setId(rs.getInt("id"));
        e.setNombreEmpresa(rs.getString("nombre_empresa"));
        e.setCuit(rs.getString("CUIT_empresa"));
        return e;
    }

    @Override
    public Empresa findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                // para consultas que devuelven datos, se utiliza executeQuery()
                // retorna un ResultSet con los resultados de la consulta
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;    // si no hay resultados, retorna null.
    }

    @Override
    public List<Empresa> findAll() throws SQLException {
        final List<Empresa> empresas = new ArrayList<>(); // retorna todas las empresas; y una lista vacía si no hay
                                                          // registros.

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                empresas.add(mapRow(rs));
            }
        }

        return empresas;
    }

    @Override
    public int update(Empresa empresa) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {

            ps.setString(1, empresa.getNombreEmpresa());
            ps.setString(2, empresa.getCuit());
            ps.setInt(3, empresa.getId());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
            // return ps.executeUpdate(); para no guardarlo primero en filas afectadas
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Empresa> findByEvaluacion(int idEvaluacion) throws SQLException {
        final List<Empresa> empresas = new ArrayList<>();// para que no se reasigne
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_EVALUACION)) {

            ps.setInt(1, idEvaluacion);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    empresas.add(mapRow(rs));
                }
            }
        }
        return empresas;
    }

    @Override
    public List<Empresa> findByTutoria(int idTutoria) throws SQLException {
        List<Empresa> empresas = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_TUTORIA)) {

            ps.setInt(1, idTutoria);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    empresas.add(mapRow(rs));
                }
            }
        }

        return empresas;
    }
}
