﻿package ar.org.centro8.java.curso.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.java.curso.entities.Evaluacion;
import ar.org.centro8.java.curso.entities.enums.NombreEvaluador;
import ar.org.centro8.java.curso.entities.enums.NormaEvaluada;
import ar.org.centro8.java.curso.entities.enums.ProvinciaDeEvaluacion;
import ar.org.centro8.java.curso.entities.enums.Resultado;

import ar.org.centro8.java.curso.repositories.interfaces.IEvaluacionDAO;

@Repository
public class EvaluacionDAO implements IEvaluacionDAO {

    // creamos un objeto de DataSource que nos permite obtener la conexión a la base
    // de datos.

    private final DataSource dataSource;

    private static final String SQL_CREATE = "INSERT INTO Evaluacion (fecha_evaluacion, provincia_evaluacion, norma_evaluada, resultado, nombre_evaluador, id_tutoria, id_empresa) VALUES (?, ?, ?, ?, ?, ?, ?)";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM Evaluacion WHERE id=?";
    private static final String SQL_FIND_ALL = "SELECT * FROM Evaluacion";
    private static final String SQL_UPDATE = "UPDATE Evaluacion SET fecha_evaluacion=?, provincia_evaluacion=?, norma_evaluada=?, resultado=?, nombre_evaluador=? WHERE id=?";
    private static final String SQL_DELETE = "DELETE FROM Evaluacion WHERE id=?";
    private static final String SQL_FIND_BY_EMPRESA = "SELECT * FROM Evaluacion WHERE id_empresa = ?";
    private static final String SQL_FIND_BY_TUTORIA = "SELECT * FROM Evaluacion WHERE id_tutoria=?";
    private static final String SQL_FIND_BY_NORMA_EVALUADA = "SELECT * FROM Evaluacion WHERE norma_evaluada = ?";
    private static final String SQL_FIND_BY_RESULTADO = "SELECT * FROM Evaluacion WHERE resultado = ?";
    private static final String SQL_FIND_BY_PROVINCIA = "SELECT * FROM Evaluacion WHERE provincia_evaluacion = ?";
    private static final String SQL_FIND_BY_FECHA_DE_EVALUACION = "SELECT * FROM Evaluacion WHERE fecha_evaluacion = ?";

    public EvaluacionDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Evaluacion evaluacion) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {

            ps.setDate(1, new java.sql.Date(evaluacion.getFechaEvaluacion().getTime()));
            ps.setString(2, evaluacion.getProvinciaDeEvaluacion().name());
            ps.setString(3, evaluacion.getNormaEvaluada().name());
            ps.setString(4, evaluacion.getResultado().name());
            ps.setString(5, evaluacion.getNombreEvaluador().name());
            ps.setInt(6, evaluacion.getId_tutoria());
            ps.setInt(7, evaluacion.getId_empresa());

            ps.executeUpdate(); // ejecuta el INSERT

            // Captura el id autogenerado
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    evaluacion.setId(keys.getInt(1));
                }
            }
        }
    }

    private Evaluacion mapRow(ResultSet rs) throws SQLException {
        Evaluacion ev = new Evaluacion();

        ev.setId(rs.getInt("id"));

        ev.setFechaEvaluacion(rs.getDate("fecha_evaluacion"));

        // value of, convierte las cadenas a enums
        ev.setProvinciaDeEvaluacion(ProvinciaDeEvaluacion.valueOf(rs.getString("provincia_evaluacion")));

        ev.setNormaEvaluada(
                NormaEvaluada.valueOf(rs.getString("norma_evaluada")));

        ev.setResultado(
                Resultado.valueOf(rs.getString("resultado")));

        ev.setNombreEvaluador(
                NombreEvaluador.valueOf(rs.getString("nombre_evaluador")));

        // relaciones con otras tablas (FK)
        ev.setId_tutoria(rs.getInt("id_tutorias"));
        ev.setId_empresa(rs.getInt("id_empresas"));

        return ev;
    }

    @Override
    public Evaluacion findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                // para consultas que devuelven datos, se utiliza executeQuery()
                // retorna un ResultSet con los resultados de la consulta
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Evaluacion> findAll() throws SQLException {
        List<Evaluacion> evaluaciones = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                evaluaciones.add(mapRow(rs));
            }
        }
        return evaluaciones;
    }

    @Override
    public int update(Evaluacion evaluacion) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {

            ps.setDate(1, new java.sql.Date(evaluacion.getFechaEvaluacion().getTime()));
            ps.setString(2, evaluacion.getProvinciaDeEvaluacion().name());
            ps.setString(3, evaluacion.getNormaEvaluada().name());
            ps.setString(4, evaluacion.getResultado().name());
            ps.setString(5, evaluacion.getNombreEvaluador().name());
            ps.setInt(6, evaluacion.getId_tutoria());
            ps.setInt(7, evaluacion.getId_empresa());
            ps.setInt(8, evaluacion.getId());

            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Evaluacion> findByEmpresa(int idEmpresa) throws SQLException {
        List<Evaluacion> evaluaciones = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_EMPRESA)) {

            ps.setInt(1, idEmpresa);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    evaluaciones.add(mapRow(rs));
                }
            }
        }

        return evaluaciones;
    }

    @Override
    public List<Evaluacion> findByTutoria(int idTutoria) throws SQLException {
        List<Evaluacion> evaluaciones = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_TUTORIA)) {

            ps.setInt(1, idTutoria);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    evaluaciones.add(mapRow(rs));
                }
            }
        }

        return evaluaciones;
    }

    

    @Override
    public List<Evaluacion> findByNormaEvaluada(NormaEvaluada normaEvaluada) throws SQLException {
        List<Evaluacion> evaluaciones = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_NORMA_EVALUADA)) {

            ps.setString(1, normaEvaluada.name());

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    evaluaciones.add(mapRow(rs));
                }
            }
        }

        return evaluaciones;
    }
    @Override
    public List<Evaluacion> findByResultado(Resultado resultado) throws SQLException {
        List<Evaluacion> evaluaciones = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_RESULTADO)) {

            ps.setString(1, resultado.name());

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    evaluaciones.add(mapRow(rs));
                }
            }
        }

        return evaluaciones;
    }

    @Override
    public List<Evaluacion> findByProvincia(ProvinciaDeEvaluacion provincia) throws SQLException {
        List<Evaluacion> evaluaciones = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_PROVINCIA)) {

            ps.setString(1, provincia.name());

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    evaluaciones.add(mapRow(rs));
                }
            }
        }

        return evaluaciones;
    }

    @Override
    public List<Evaluacion> findByFecha(Date fecha) throws SQLException {
        List<Evaluacion> evaluaciones = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_FECHA_DE_EVALUACION)) {

            ps.setDate(1, new java.sql.Date(fecha.getTime()));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    evaluaciones.add(mapRow(rs));
                }
            }
        }

        return evaluaciones;
    }

    
}
