﻿package ar.org.centro8.java.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;
import ar.org.centro8.java.curso.entities.Empresa;

public interface IEmpresaDAO {

  /**
   * Método para crear una empresa. Recibe como parámetro un objeto del tipo
   * Empresa y guarda el registro en la base de datos.
   * 
   * @param empresa -> recibe un objeto de empresa al que luego le setea el id
   *                autogenerado por la base
   * @throws SQLException
   */

  void create(Empresa empresa) throws SQLException;

  /**
   * Método que busca una empresa por su id. Recibe como parámetro el id de la
   * empresa a buscar y lo retorna como un objeto de la clase Empresa.
   * 
   * @param id
   * @return
   * @throws SQLException
   */
  Empresa findById(int id) throws SQLException;

  /**
   * Método para obtener el listado de todas las empresas. No recibe parámetro y
   * devuelve una lista de todos los registros de empresas en la base de datos.
   * 
   * @return
   * @throws SQLException
   */
  List<Empresa> findAll() throws SQLException;

  /**
   * Método para actualizar una empresa en la base de datos. Recibe como parámetro
   * un objeto del tipo Empresa y actualiza sus datos en el registro de la base de
   * datos.
   * 
   * @param empresa
   * @return
   * @throws SQLException
   */
  int update(Empresa empresa) throws SQLException;

  /**
   * Método para eliminar una empresa en la base de datos. Recibe como parámetro
   * un id que identifica a la empresa. Devuelve un entero indicando si se pudo
   * eliminar el registro.
   * 
   * @param id
   * @return
   * @throws SQLException
   */
  int delete(int id) throws SQLException;

  /**
   * Método que busca empresas por su id de evaluación. Recibe como parámetro el
   * id de la evaluación y devuelve una lista con todos los registros de las
   * empresas.
   * 
   * @param idEvaluacion
   * @return
   * @throws SQLException
   */
  List<Empresa> findByEvaluacion(int idEvaluacion) throws SQLException;

  /**
   * Método que busca empresas por su id de tutoría. Recibe como parámetro el id
   * de la tutoría y devuelve una lista con todos los registros de las empresas.
   * 
   * @param idTutoria
   * @return
   * @throws SQLException
   */
  List<Empresa> findByTutoria(int idTutoria) throws SQLException;
}
