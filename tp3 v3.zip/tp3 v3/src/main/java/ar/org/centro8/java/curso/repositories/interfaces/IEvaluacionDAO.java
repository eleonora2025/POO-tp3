﻿package ar.org.centro8.java.curso.repositories.interfaces;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import ar.org.centro8.java.curso.entities.Evaluacion;
import ar.org.centro8.java.curso.entities.enums.NormaEvaluada;
import ar.org.centro8.java.curso.entities.enums.ProvinciaDeEvaluacion;
import ar.org.centro8.java.curso.entities.enums.Resultado;

public interface IEvaluacionDAO {

    /**
     * Método para crear una evaluación. Recibe como parámetro un objeto del tipo
     * Evaluacion y guarda el registro en la base de datos.
     * 
     * @param evaluacion -> recibe un objeto de evaluación al que luego le setea el
     *                   id autogenerado por la base
     * @throws SQLException
     */

    void create(Evaluacion evaluacion) throws SQLException;

    /**
     * Método que busca una evaluación por su id. Recibe como parámetro el id de la
     * evaluación a buscar y lo retorna como un objeto de la clase Evaluacion.
     * 
     * @param id
     * @return
     * @throws SQLException
     */
    Evaluacion findById(int id) throws SQLException;

    /**
     * Método para obtener el listado de todas las evaluaciones. No recibe
     * parámetros y devuelve una lista de todos los registros de evaluaciones en la
     * base de datos.
     * 
     * @return
     * @throws SQLException
     */
    List<Evaluacion> findAll() throws SQLException;

    /**
     * Método para actualizar una evaluación en la base de datos. Recibe como
     * parámetro un objeto del tipo Evaluacion y actualiza sus datos en el registro
     * de la base de datos.
     * 
     * @param evaluacion
     * @return
     * @throws SQLException
     */
    int update(Evaluacion evaluacion) throws SQLException;

    /**
     * Método para eliminar una evaluación en la base de datos. Recibe como
     * parámetro un id que identifica a la evaluación. Devuelve un entero indicando
     * si se pudo eliminar el registro.
     * 
     * @param id
     * @return
     * @throws SQLException
     */
    int delete(int id) throws SQLException;

    /**
     * Método que busca evaluaciones por su id de empresa. Recibe como parámetro el
     * id de la empresa y devuelve una lista con todas las evaluaciones de esa
     * empresa.
     * 
     * @param idEmpresa
     * @return
     * @throws SQLException
     */
    List<Evaluacion> findByEmpresa(int idEmpresa) throws SQLException;

    /**
     * Método que busca evaluaciones por su id de tutoría. Recibe como parámetro el
     * id de la tutoría y devuelve una lista con todas las evaluaciones de esa
     * tutoria.
     * 
     * @param idTutoria
     * @return
     * @throws SQLException
     */
    List<Evaluacion> findByTutoria(int idTutoria) throws SQLException;

    /**
     * Método para listar evaluaciones en la base de datos, según su resultado
     * Recibe como parámetro un objeto del tipo Resultado y devuelve una lista de
     * los registros de evaluaciones según ese resultado
     * 
     * @param resultado
     * @return
     * @throws SQLException
     */
    List<Evaluacion> findByResultado(Resultado resultado) throws SQLException;

    /**
     * Método para listar evaluaciones en la base de datos, por provincia de
     * evaluacion
     * Recibe como parámetro un objeto del tipo ProvinciaDeEvaluacion y devuelve una
     * lista de
     * los registros de evaluaciones según la provincia de evaluacion que se haya
     * entrado como parámetro.
     * 
     * @param provinciaDeEvaluacion
     * @return
     * @throws SQLException
     */
    List<Evaluacion> findByProvincia(ProvinciaDeEvaluacion provinciadEvaluacion) throws SQLException;


     /**
     * Método para listar evaluaciones en la base de datos, por fecha de evaluacion
     * Recibe como parámetro un objeto del tipo Date y devuelve una lista de
     * los registros de evaluaciones según la fecha de evaluacion entrada como parámetro.
     * 
     * @param fecha
     * @return
     * @throws SQLException
     */
    List<Evaluacion> findByFecha(Date fecha) throws SQLException;

 /**
     * Método para listar evaluaciones en la base de datos, por la norma evaluada
     * Recibe como parámetro un objeto del tipo NormaEvaluada y devuelve una
     * lista de los registros de evaluaciones según la norma que se haya entrado como parámetro.
     * 
     * @param normaEvaluada
     * @return
     * @throws SQLException
     */
    List<Evaluacion> findByNormaEvaluada(NormaEvaluada normaEvaluada) throws SQLException;

}
