﻿-- 1. contar Tutorías totales.
Select count(*) as total_tutorias
from tutorias;


-- 1.2. Contar tutorías por provincia de residencia, con porcentajes.
select provincia_residencia,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by provincia_residencia
order by provincia_residencia;


-- 1.3. Contar tutorías por edad, (19 a 21, 22 a 30, 31 a 40, 41 a 50, 51 a 60, más de 60.) con porcentajes.
select case
        when edad between 19 and 21 then '19-21'
        when edad between 22 and 30 then '22-30'
        when edad between 31 and 40 then '31-40'
        when edad between 41 and 50 then '41-50'
        when edad between 51 and 60 then '51-60'
        when edad > 60 then 'Más de 60'
        else 'Menor de 19'
    end as rango_edad,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by rango_edad
order by case
        when rango_edad = '19-21' then 1
        when rango_edad = '22-30' then 2
        when rango_edad = '31-40' then 3
        when rango_edad = '41-50' then 4
        when rango_edad = '51-60' then 5
        when rango_edad = 'Más de 60' then 6
        else 0
    end;


-- 1.4. Contar tutorías por nacionalidad, con porcentajes.
select nacionalidad,
    count(*) ascantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by nacionalidad
order by nacionalidad;


-- 1.5. Contar tutorías por género, con porcentajes.
select genero,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by genero
order by genero;


-- 1.6. Contar tutorías por nivel educativo, con porcentajes.
select nivel_educativo,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by nivel_educativo
order by nivel_educativo;


-- 1.7.1. Contar tutorías por edad, (19 a 21, 22 a 30, 31 a 40, 41 a 50, 51 a 60, más de 60.) y género, con porcentajes.
select rango_edad,
    genero,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from (
        select case
                when edad between 19 and 21 then '19 a 21'
                when edad between 22 and 30 then '22 a 30'
                when edad between 31 and 40 then '31 a 40'
                when edad between 41 and 50 then '41 a 50'
                when edad between 51 and 60 then '51 a 60'
                when edad > 60 then 'Más de 60'
            end as rango_edad,
            genero
        from tutorias
        where edad >= 19
    ) as sub
Group by rango_edad,
    genero
Order by Case
        rango_edad
        when '19 a 21' then 1
        when '22 a 30' then 2
        when '31 a 40' then 3
        when '41 a 50' then 4
        when '51 a 60' then 5
        when 'Más de 60' then 6
    end,
    genero;


-- 1.7.2. Contar tutorías por edad, (19 a 21, 22 a 30, 31 a 40, 41 a 50, 51 a 60, más de 60.) y nacionalidad, con porcentajes.
select rango_edad,
    nacionalidad,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from (
        select case
                when edad between 19 and 21 then '19 a 21'
                when edad between 22 and 30 then '22 a 30'
                when edad between 31 and 40 then '31 a 40'
                when edad between 41 and 50 then '41 a 50'
                when edad between 51 and 60 then '51 a 60'
                when edad > 60 then 'Más de 60'
            end as rango_edad,
            nacionalidad
        from tutorias
        where edad >= 19
    ) as sub
Group by rango_edad,
    nacionalidad
Order by case
        rango_edad
        when '19 a 21' then 1
        when '22 a 30' then 2
        when '31 a 40' then 3
        when '41 a 50' then 4
        when '51 a 60' then 5
        when 'Más de 60' then 6
    end,
    nacionalidad;


-- 1.7.3. Contar tutorías por edad, (19 a 21, 22 a 30, 31 a 40, 41 a 50, 51 a 60, más de 60.) y provincia de residencia, con porcentajes.
select rango_edad,
    provincia_residencia,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from (
        select case
                when edad between 19 and 21 then '19 a 21'
                when edad between 22 and 30 then '22 a 30'
                when edad between 31 and 40 then '31 a 40'
                when edad between 41 and 50 then '41 a 50'
                when edad between 51 and 60 then '51 a 60'
                when edad > 60 then 'Más de 60'
            end as rango_edad,
            provincia_residencia
        from tutorias
        where edad >= 19
    ) as sub
Group by rango_edad,
    provincia_residencia
Order by Case
        rango_edad
        when '19 a 21' then 1
        when '22 a 30' then 2
        when '31 a 40' then 3
        when '41 a 50' then 4
        when '51 a 60' then 5
        when 'Más de 60' then 6
    end,
    provincia_residencia;


-- 1.7.4. Contar tutorías por edad, (19 a 21, 22 a 30, 31 a 40, 41 a 50, 51 a 60, más de 60.) y nivel educativo, con porcentajes.
select rango_edad,
    nivel_educativo,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from (
        select case
                when edad between 19 and 21 then '19 a 21'
                when edad between 22 and 30 then '22 a 30'
                when edad between 31 and 40 then '31 a 40'
                when edad between 41 and 50 then '41 a 50'
                when edad between 51 and 60 then '51 a 60'
                when edad > 60 then 'Más de 60'
            end as rango_edad,
            nivel_educativo
        from tutorias
        where edad >= 19
    ) as sub
Group by rango_edad,
    nivel_educativo
Order by case
        rango_edad
        when '19 a 21' then 1
        when '22 a 30' then 2
        when '31 a 40' then 3
        when '41 a 50' then 4
        when '51 a 60' then 5
        when 'Más de 60' then 6
    end,
    nivel_educativo;


-- 1.8.1. Contar tutorías por nacionalidad y género, con porcentajes.
select nacionalidad,
    genero,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by nacionalidad,
    genero
order by nacionalidad,
    genero;


-- 1.8.2 .Contar tutorías por nacionalidad y nivel educativo, con porcentajes.
select nacionalidad,
    nivel_educativo,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by nacionalidad,
    nivel_educativo
order by nacionalidad,
    nivel_educativo;


-- 1.8.3. Contar tutorías por nacionalidad y provincia de residencia, con porcentajes.
select nacionalidad,
    provincia_residencia,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by nacionalidad,
    provincia_residencia
order by nacionalidad,
    provincia_residencia;


-- 1.9.1. Contar tutorías por nivel educativo y género, con porcentajes.
select nivel_educativo,
    genero,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by nivel_educativo,
    genero
order by nivel_educativo,
    genero;


-- 1.9.2. Contar tutorías por nivel educativo y provincia de residencia, con porcentajes.
select nivel_educativo,
    provincia_residencia,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by nivel_educativo,
    provincia_residencia
order by nivel_educativo,
    provincia_residencia;


-- 1.10. Contar tutorías por género y provincia de residencia, con porcentajes.
select genero,
    provincia_residencia,
    count(*) as cantidad_tutorias,
    round(
        count(*) * 100.0 / (
            select count(*)
            from tutorias
        ),
        2
    ) as porcentaje
from tutorias
group by genero,
    provincia_residencia
order by genero,
    provincia_residencia;



-- 2. EVALUACIONES
-- 2.1. Obtener la cantidad de evaluaciones
Select count(*) as total_evaluaciones
from evaluaciones;


-- 2.2. Cantidad de evaluaciones por tutorías.
select t.id as id_tutoria,
    t.apellido_nombre,
    count(ev.id) as cantidad_evaluaciones
from tutorias t
    left join evaluaciones ev on t.id = ev.id_tutorias
group by t.id
order by cantidad_evaluaciones desc;


-- 2.3. Cantidad de evaluaciones por año de evaluación, con porcentajes.
Select year(fecha_evaluacion) as año,
    count(*) as cantidad_evaluaciones
from evaluaciones
group by year(fecha_evaluacion)
order by año;


-- 2.4. Cantidad de evaluaciones por norma evaluada, con porcentajes.
select norma_evaluada,
    count(*) as cantidad,
    round(
        count(*) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje
from evaluaciones
group by norma_evaluada
order by norma_evaluada;


-- 2.5. Cantidad de evaluaciones por provincia de evaluación, con porcentajes.
select ev.provincia_evaluacion,
    count(*) as cantidad_evaluaciones,
    round(
        count(*) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje
from evaluaciones ev
group by ev.provincia_evaluacion
order by porcentaje desc;


-- 2.6. Cantidad de evaluaciones por año evaluación y por norma evaluada, con porcentajes.
select year(fecha_evaluacion) as año,
    norma_evaluada,
    count(*) as cantidad,
    round(
        count(*) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje_total
from evaluaciones
group by year(fecha_evaluacion),
    norma_evaluada
order by año,
    norma_evaluada;


-- 2.6.1. Cantidad evaluaciones por año evaluación y por provincia de evaluación, con porcentajes.
select year (fecha_evaluacion) as año,
    provincia_evaluacion,
    count(*) as cantidad_evaluaciones,
    round(
        count(*) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje
from evaluaciones
group by year(fecha_evaluacion),
    provincia_evaluacion
order by año,
    provincia_evaluacion;


-- 2.6.2. Cantidad de evaluaciones por año de evaluación, por norma evaluada y su resultado, con porcentajes.
select year(fecha_evaluacion) as año,
    norma_evaluada,
    resultado,
    count(*) as cantidad,
    round(
        count(*) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje_total
from evaluaciones
group by year(fecha_evaluacion),
    norma_evaluada,
    resultado
order by año,
    norma_evaluada,
    resultado;


-- 2.7. Cantidad  de evaluaciones por norma evaluada, por resultado, con porcentajes.
select norma_evaluada,
    resultado,
    count(*) as cantidad,
    round(
        count(*) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje
from evaluaciones
group by norma_evaluada,
    resultado
order by norma_evaluada,
    resultado;


-- 2.8. Cantidad de evaluaciones por norma evaluada y por provincia de evaluación, con porcentajes.
select provincia_evaluacion,
    norma_evaluada,
    count(*) as cantidad,
    round(
        count(*) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje_total
from evaluaciones
group by provincia_evaluacion,
    norma_evaluada
order by provincia_evaluacion,
    norma_evaluada;


-- 2.8.1. Cantidad de evaluaciones por norma evaluada, por provincia de evaluación, por año con porcentajes.
Select year(fecha_evaluacion) as año,
    provincia_evaluacion,
    norma_evaluada,
    count(*) as cantidad,
    round(
        count(*) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje_total
from evaluaciones
group by year(fecha_evaluacion),
    norma_evaluada,
    provincia_evaluacion
order by año,
    provincia_evaluacion,
    norma_evaluada;

-- EMPRESAS
-- 3. Cantidad de evaluaciones por empresa, con porcentajes.
select e.nombre_empresa,
    count(ev.id) as cantidad,
    round(
        count(ev.id) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje
from empresas e
    left join evaluaciones ev on ev.id_empresas = e.id
group by e.nombre_empresa
order by e.nombre_empresa;


-- 3.1. Cantidad de evaluaciones por empresa y por año, con porcentajes.
select year(ev.fecha_evaluacion) as año,
    e.nombre_empresa,
    count(*) as cantidad,
    round(
        count(*) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje_total
from evaluaciones ev
    left join empresas e on ev.id_empresas = e.id
group by year(ev.fecha_evaluacion),
    e.nombre_empresa
order by año,
    e.nombre_empresa;


-- 3.2. Cantidad de evaluaciones por empresa, por provincia de evaluación, con porcentajes.
select ev.provincia_evaluacion,
    e.nombre_empresa,
    count(*) as cantidad_evaluaciones,
    round(
        count(*) * 100.0 / (
            select count(*)
            from evaluaciones
        ),
        2
    ) as porcentaje
from evaluaciones ev
    left join empresas e on ev.id_empresas = e.id
group by e.nombre_empresa,
    ev.provincia_evaluacion
order by ev.provincia_evaluacion;


-- 3.3. Cantidad de evaluaciones por empresa, por norma_evaluada, por resultado, con porcentajes.
select e.nombre_empresa,
    ev.norma_evaluada,
    ev.resultado,
    count(*) as cantidad,
    round(
        count(*) * 100.0 / (
            select count(*) fromevaluaciones
        ),
        2
    ) as porcentaje
from empresas e
    left join evaluaciones ev ON e.id = ev.id_empresas
group by e.nombre_empresa,
    ev.norma_evaluada,
    ev.resultado
order by e.nombre_empresa,
    ev.norma_evaluada;