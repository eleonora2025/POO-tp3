﻿drop database dcc1;
create database dcc1;
use dcc1;


drop table if exists empresas;
create table empresas (
    id int auto_increment primary key,
    nombre_empresa varchar(100) not null,
    CUIT_empresa char(11) not null unique
);



drop table if exists tutorias;
create table tutorias (
    id int auto_increment primary key,
    apellido_nombre varchar(100) not null,
    CUIT char(11) not null unique,
    provincia_residencia enum( 'CABA','Buenos Aires', 'Córdoba', 'Misiones', 'Río Negro', 'Entre Ríos', 'Corrientes',    'La Pampa', 'San Luis', 'Santa Fe', 'Santiago del Estero' ),
    edad int check (edad > 0),
    nacionalidad enum('Argentina', 'Boliviana', 'Paraguaya', 'Peruana'),
    genero enum('Masculino', 'Femenino'),
    nivel_educativo enum( 'Primaria Incompleta', 'Primaria Completa', 'Secundaria Incompleta', 'Secundaria Completa',        'Terciario Incompleto', 'Terciario Completo', 'Universitario Incompleto', 'Universitario Completo' ),
    nombre_tutor enum( 'Paoletti, María Eleonora', 'Sagarna, Valeria', 'Sánchez, Roberto Esteban' )
);




drop table if exists evaluaciones;
create table evaluaciones (
    id int auto_increment primary key,
    id_tutorias int not null,
    id_empresas int not null,
    fecha_evaluacion date not null,
    provincia_evaluacion enum( 'CABA', 'Buenos Aires', 'Córdoba', 'Misiones', 'Río Negro', 'Entre Ríos' ),
    norma_evaluada enum( 'Albañil',  'Armador de H°A°', 'Carpintero de H°A°', 'Auxiliar General' ),
    resultado enum( 'Competente', 'Aún No Competente', 'No Certificar' ),
    nombre_evaluador enum( 'Mazzei, María Cecilia', 'Domínguez, Martín Erasmo', 'Montenegro, Ramiro' ),
    foreign key (id_tutorias) references tutorias(id),
    foreign key (id_empresas) references empresas(id)
);
