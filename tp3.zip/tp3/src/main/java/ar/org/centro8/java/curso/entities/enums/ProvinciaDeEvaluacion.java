package ar.org.centro8.java.curso.entities.enums;

public enum ProvinciaDeEvaluacion {
    CABA,
    Buenos_Aires,
    Córdoba,
    Misiones,
    Corrientes,
    Río_Negro,
    San_Juan,
    Entre_Ríos;

}
