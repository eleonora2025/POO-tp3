package ar.org.centro8.java.curso.entities.enums;

public enum Resultado {
    Competente,
    Aún_No_Competente,
    No_Certificar;

}
