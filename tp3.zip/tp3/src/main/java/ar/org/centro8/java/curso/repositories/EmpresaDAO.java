package ar.org.centro8.java.curso.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.java.curso.entities.Empresa;
import ar.org.centro8.java.curso.repositories.interfaces.IEmpresaDAO;

/*
En el mundo del desarrollo de software, cuando hablamos de clases que se encargan de interactuar 
con la base de datos para guardar, buscar o actualizar los objetos se van a referir como DAO 
(Data Access Object) y Repository (Repositorio).
Ambos cumplen el mismo propósito fundamental: abstraer la lógica de persistencia para que el resto 
de nuestra aplicación no tenga que preocuparse por los detalles de SQL o de cómo funciona la base 
de datos.
'DAO' es el término más tradicional para una clase que implementa directamente estas operaciones 
de acceso a datos de bajo nivel con SQL.
'Repository' es un concepto más moderno y de más alto nivel, muy popular en frameworks como Spring 
Boot con Spring Data JPA. Un Repositorio sería como una 'colección de objetos' en memoria, aunque 
por detrás esté guardándolos en la base de datos.
*/

@Repository
public class EmpresaDAO implements IEmpresaDAO {

    // creamos un objeto de DataSource que nos permite obtener la conexión a la base
    // de datos.

    private final DataSource dataSource;

    private static final String SQL_CREATE = "INSERT INTO Empresa (nombre_empresa, CUIT_empresa) VALUES (?, ?)";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM Empresa WHERE id=?";
    private static final String SQL_FIND_ALL = "SELECT * FROM Empresa";
    private static final String SQL_UPDATE = "UPDATE Empresa SET nombre_empresa=?, CUIT_empresa=? WHERE id=?";
    private static final String SQL_DELETE = "DELETE FROM Empresa WHERE id=?";
    private static final String SQL_FIND_BY_EVALUACION = "SELECT * FROM Empresa WHERE id_evaluacion=?";
    private static final String SQL_FIND_BY_TUTORIA = "SELECT * FROM Empresa WHERE id_tutoria = ?";

    public EmpresaDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    // de esta manera el repositorio queda configurado con la fuente de conexiones
    // que usará siempre
    // el repositorio no crea su propio datasource, si no que se le proporciona uno
    // configurado Con HikariCP.

    @Override
    public void create(Empresa empresa) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, empresa.getNombreEmpresa());
            ps.setString(2, empresa.getCuit());

            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    empresa.setId(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Empresa findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                // para consultas que devuelven datos, se utiliza executeQuery()
                // retorna un ResultSet con los resultados de la consulta
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Empresa> findAll() throws SQLException {
        List<Empresa> empresas = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                empresas.add(mapRow(rs));
            }
        }

        return empresas;
    }

    @Override
    public int update(Empresa empresa) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {

            ps.setString(1, empresa.getNombreEmpresa());
            ps.setString(2, empresa.getCuit());
            ps.setInt(3, empresa.getId());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Empresa> findByEvaluacion(int idEvaluacion) throws SQLException {
        List<Empresa> empresas = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_EVALUACION)) {

            ps.setInt(1, idEvaluacion);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    empresas.add(mapRow(rs));
                }
            }
        }
        return empresas;
    }

    @Override
    public List<Empresa> findByTutoria(int idTutoria) throws SQLException {
        List<Empresa> empresas = new ArrayList<>();

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_TUTORIA)) {

            ps.setInt(1, idTutoria);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    empresas.add(mapRow(rs));
                }
            }
        }

        return empresas;
    }

    private Empresa mapRow(ResultSet rs) throws SQLException {
        Empresa e = new Empresa();
        e.setId(rs.getInt("id"));
        e.setNombreEmpresa(rs.getString("nombre_empresa"));
        e.setCuit(rs.getString("CUIT_empresa"));
        return e;
    }
}
