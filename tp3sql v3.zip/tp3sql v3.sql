drop database if exists dcc1;
create database dcc1;
use dcc1;

drop table if exists empresas;
create table empresas (
id int auto_increment primary key,
nombre_empresa varchar(100) not null,
CUIT_empresa char(11) not null unique
);

drop table if exists tutorias;
create table tutorias (
id int auto_increment primary key,
apellido_nombre varchar(100) not null,
CUIT char(11) not null unique,
provincia_residencia enum( 'CABA','Buenos Aires', 'Córdoba', 'Misiones', 'Río Negro', 'Entre Ríos', 'Corrientes',    'La Pampa','San Luis', 'Santa Fe','Santiago del Estero' ),
edad int check (edad > 0),
nacionalidad enum('Argentina', 'Boliviana', 'Paraguaya', 'Peruana'),
genero enum('Masculino', 'Femenino'),
nivel_educativo enum( 'Primaria Incompleta', 'Primaria Completa', 'Secundaria Incompleta', 'Secundaria Completa',        'Terciario Incompleto', 'Terciario Completo', 'Universitario Incompleto', 'Universitario Completo' ),
nombre_tutor enum( 'Paoletti, María Eleonora', 'Sagarna, Valeria', 'Sánchez, Roberto Esteban' )
);

drop table if exists evaluaciones;
create table evaluaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_tutorias INT NOT NULL,
    id_empresas INT NOT NULL,
    fecha_evaluacion DATE NOT NULL,
    provincia_evaluacion ENUM('CABA', 'Buenos Aires', 'Córdoba', 'Misiones', 'Río Negro', 'Entre Ríos'),
    norma_evaluada ENUM('Albañil', 'Armador de H°A°', 'Carpintero de H°A°', 'Auxiliar General'),
    resultado ENUM('Competente', 'Aún No Competente', 'No Certificar'),
    nombre_evaluador ENUM('Mazzei, María Cecilia', 'Domínguez, Martín Erasmo', 'Montenegro, Ramiro'),
    FOREIGN KEY (id_tutorias) REFERENCES tutorias(id),
    FOREIGN KEY (id_empresas) REFERENCES empresas(id)
);


show tables;
describe tutorias;
describe empresas;
describe evaluaciones;


insert into empresas (nombre_empresa, CUIT_empresa) values
('COARCO S.A.', '30516500634'),
('SZCZECH SA-L&C CONSTRUCCIONES SA-OBRA PARQUE BERDUC-UNION TRANSITORIA', '30717589943'),
('INGENIERO PELLEGRINET SA', '30574832949'),
('OVERCON S.R.L', '30712048588'),
('CONSTRUCTORA BASE 8 S.R.L.', '30716522977'),
('ING. PEDRO MINERVINO S.A', '30506069374'),
('TOSUD CONSTRUCTORA S.A.', '30703938023'),
('ALFA MS CONSTRUCCIONES S.R.L.', '30717882810'),
('EDYCA S.A', '30608571236'),
('B. Y L. S.A', '30604580508');

select * from empresas;


 

insert into tutorias (apellido_nombre, CUIT, provincia_residencia, edad, nacionalidad, genero, nivel_educativo, nombre_tutor) values
('CAÑETE RAQUEL SANDRA', '27260080461', 'Santa Fe', 30, 'Argentina', 'Femenino', 'Secundaria Completa', 'Paoletti, María Eleonora'),
('MIÑO JUAN CARLOS', '20173692073', 'Córdoba', 42, 'Argentina', 'Masculino', 'Primaria Completa', 'Sánchez, Roberto Esteban'),
('MIÑO VICTOR ADRIAN', '20275267512', 'Santiago del Estero', 27, 'Argentina', 'Masculino', 'Primaria Completa', NULL),
('MIÑO HUGO ORLANDO', '23287070519', 'Córdoba', 27, 'Argentina', 'Masculino', 'Secundaria Incompleta', 'Sánchez, Roberto Esteban'),
('RAMIREZ DIAZ DIANA DURLEY', '27958175855', 'CABA', 17, 'Boliviana', 'Femenino', 'Terciario Completo', 'Paoletti, María Eleonora'),
('CABRERA DIAZ ANTONIO', '20942632445', 'Buenos Aires', 31, 'Paraguaya', 'Masculino', 'Secundaria Completa', NULL),
('BENITEZ MERELES JUAN CARLOS', '23953833379', 'Río Negro', 21, 'Paraguaya', 'Masculino', 'Secundaria Completa', 'Sánchez, Roberto Esteban'),
('SAMBONINI LUCAS SEBASTIAN', '20281210220', 'Buenos Aires', 38, 'Argentina', 'Masculino', 'Secundaria Incompleta', 'Paoletti, María Eleonora'),
('CORDOVA JORGE EDINSON TEODOSIO', '20950622874', 'Buenos Aires', 33, 'Peruana', 'Femenino', 'Secundaria Completa', 'Sagarna, Valeria'),
('CHAVEZ COQUINCHE ROKERTH DIEGO', '20957561722', 'CABA', 24, 'Peruana', 'Femenino', 'Secundaria Completa', 'Sagarna, Valeria'),
('BENITEZ MERELES LIDIO E.', '24939996679', 'Buenos Aires', 26, 'Paraguaya', 'Masculino', 'Primaria Completa', NULL),
('FRIAS SERAFINA MERICIA', '23185726894', 'Buenos Aires', 53, 'Argentina', 'Femenino', 'Primaria Completa', 'Paoletti, María Eleonora'),
('CABRERA DELVALLE WILFRIDO', '20955183437', 'La Pampa', 34, 'Paraguaya', 'Masculino', 'Primaria Incompleta', NULL),
('SAMUDIO YESSICA JAZMIN', '27381884274', 'Buenos Aires', 29, 'Argentina', 'Femenino', 'Secundaria Completa', 'Sagarna, Valeria'),
('CORONADO JOANA ELIZABETH', '27383626825', 'Buenos Aires', 28, 'Boliviana', 'Femenino', 'Secundaria Completa', 'Sagarna, Valeria'),
('SEGOVIA GISELA VIRGINIA', '27338587576', 'Buenos Aires', 34, 'Argentina', 'Femenino', 'Secundaria Completa', 'Paoletti, María Eleonora'),
('CEJAS OLGA EVA', '27266978613', 'CABA', 44, 'Argentina', 'Femenino', 'Secundaria Incompleta', 'Sagarna, Valeria'),
('LIBRERA ROCIO LEYLA MAILEN', '27399668870', 'Buenos Aires', 26, 'Peruana', 'Femenino', 'Secundaria Completa', 'Paoletti, María Eleonora'),
('MAIDANA YANINA ELIZABETH', '27316401401', 'Buenos Aires', 37, 'Argentina', 'Femenino', 'Secundaria Incompleta', 'Sagarna, Valeria'),
('MIÑO JUAN CARLOS', '20228978958', 'Córdoba', 51, 'Argentina', 'Masculino', 'Primaria Incompleta', 'Paoletti, María Eleonora'),
('FERNANDEZ CAMILA DEL ROSARIO', '27415015637', 'Misiones', 26, 'Argentina', 'Femenino', 'Universitario Incompleto', 'Sagarna, Valeria'),
('REYNERO SOFIA ANTONELLA', '23406689484', 'Buenos Aires', 27, 'Argentina', 'Femenino', 'Secundaria Completa', 'Paoletti, María Eleonora'),
('RIVERO MARIANA ALEJANDRA', '27357631306', 'Entre Ríos', 43, 'Argentina', 'Femenino', 'Primaria Completa', 'Sánchez, Roberto Esteban');


select * from tutorias;



 

insert into evaluaciones (id_tutorias, id_empresas, fecha_evaluacion, provincia_evaluacion, norma_evaluada, resultado, nombre_evaluador) values
(1, 1, '2007-11-16', 'Entre Ríos', 'Auxiliar General', 'Competente', 'Montenegro, Ramiro'),
(2, 2, '2008-02-06', 'Córdoba', 'Albañil', 'Competente', 'Domínguez, Martín Erasmo'),
(3, 3, '2008-02-20', 'Córdoba', 'Carpintero de H°A°', 'Aún No Competente', 'Mazzei, María Cecilia'),
(4, 1, '2008-05-16', 'Córdoba', 'Albañil', 'Competente', 'Mazzei, María Cecilia'),
(5, 1, '2009-01-21', 'CABA', 'Auxiliar General', 'Competente', 'Montenegro, Ramiro'),
(6, 4, '2012-09-20', 'Buenos Aires', 'Carpintero de H°A°', 'No Certificar', 'Mazzei, María Cecilia'),
(7, 5, '2015-02-24', 'Río Negro', 'Armador de H°A°', 'Competente', 'Domínguez, Martín Erasmo'),
(8, 5, '2018-08-04', 'Buenos Aires', 'Armador de H°A°', 'Aún No Competente', 'Montenegro, Ramiro'),
(9, 6, '2019-01-10', 'CABA', 'Albañil', 'Competente', 'Domínguez, Martín Erasmo'),
(10, 3, '2019-01-15', 'CABA', 'Carpintero de H°A°', 'Competente', 'Montenegro, Ramiro'),
(11, 3, '2020-08-15', 'Buenos Aires', 'Auxiliar General', 'Competente', 'Mazzei, María Cecilia'),
(12, 7, '2021-10-15', 'Buenos Aires', 'Albañil', 'Aún No Competente', 'Mazzei, María Cecilia'),
(7, 5, '2022-03-14', 'Buenos Aires', 'Carpintero de H°A°', 'Competente', 'Domínguez, Martín Erasmo'),
(13, 3, '2022-03-14', 'Río Negro', 'Carpintero de H°A°', 'Competente', 'Montenegro, Ramiro'),
(6, 5, '2022-03-14', 'Río Negro', 'Albañil', 'Competente', 'Domínguez, Martín Erasmo'),
(14, 6, '2022-09-01', 'Buenos Aires', 'Auxiliar General', 'Competente', 'Montenegro, Ramiro'),
(15, 3, '2022-11-18', 'Buenos Aires', 'Carpintero de H°A°', 'Competente', 'Mazzei, María Cecilia'),
(16, 8, '2022-11-23', 'Buenos Aires', 'Auxiliar General', 'Competente', 'Mazzei, María Cecilia'),
(17, 1, '2022-11-28', 'CABA', 'Armador de H°A°', 'Competente', 'Domínguez, Martín Erasmo'),
(18, 8, '2022-12-06', 'Buenos Aires', 'Auxiliar General', 'Competente', 'Mazzei, María Cecilia'),
(19, 7, '2022-12-07', 'Buenos Aires', 'Armador de H°A°', 'Competente', 'Mazzei, María Cecilia'),
(8, 8, '2024-10-17', 'Buenos Aires', 'Armador de H°A°', 'Competente', 'Domínguez, Martín Erasmo'),
(20, 2, '2025-01-09', 'Córdoba', 'Armador de H°A°', 'Competente', 'Montenegro, Ramiro'),
(21, 8, '2025-04-20', 'Misiones', 'Albañil', 'Competente', 'Mazzei, María Cecilia'),
(8, 4, '2025-06-13', 'Buenos Aires', 'Albañil', 'No Certificar', 'Domínguez, Martín Erasmo'),
(22, 9, '2025-10-09', 'Buenos Aires', 'Albañil', 'Competente', 'Montenegro, Ramiro'),
(23, 10, '2025-11-18', 'Entre Ríos', 'Auxiliar General', 'Competente', 'Mazzei, María Cecilia');

select * from evaluaciones;

-- 1. TUTORIAS
-- 1.1. Contar Tutorías totales
Select 		count(*) as total_tutorias
from		tutorias;

-- 1.2. Contar Tutorías por provincia de residencia, con porcentajes.
select		provincia_residencia,
			count(*) ascantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje
from		tutorias
group by	provincia_residencia
order by	provincia_residencia;


-- 1.3. Contar Tutorías por edad, (19 a 21, 22 a 30, 31 a 40, 41 a 50, 51 a 60, más de 60.) con porcentajes.
select
    case
        when edad BETWEEN 19 AND 21 then '19-21'
        when edad BETWEEN 22 AND 30 then '22-30'
        when edad BETWEEN 31 AND 40 then '31-40'
        when edad BETWEEN 41 AND 50 then '41-50'
        when edad BETWEEN 51 AND 60 then '51-60'
        when edad > 60 THEN 'Más de 60'
        ELSE 'Menor de 19'
    END AS rango_edad,
    COUNT(*) AS cantidad,
    ROUND( COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2) AS porcentaje
FROM tutorias
GROUP BY rango_edad
ORDER BY 
    CASE
        when rango_edad = '19-21' then 1
        when rango_edad = '22-30' then 2
        when rango_edad = '31-40' then 3
        when rango_edad = '41-50' then 4
        when rango_edad = '51-60' then 5
        when rango_edad = 'Más de 60' then 6
        ELSE 0
    END;
    
    
-- 1.4. Contar Tutorías por nacionalidad, con porcentajes.
select		nacionalidad,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (SELECT COUNT(*) FROM tutorias), 2) AS porcentaje
from		tutorias
group by	nacionalidad
order by	nacionalidad;


-- 1.5. Contar Tutorías por género, con porcentajes.
select		genero,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from		tutorias
group by	genero
order by	genero;


-- 1.6. Contar Tutorías por nivel educativo, con porcentajes.
select		nivel_educativo,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from		tutorias
group by	nivel_educativo
order by	nivel_educativo;


-- 1.7.1. Contar Tutorías por edad, (19 a 21, 22 a 30, 31 a 40, 41 a 50, 51 a 60, más de 60.) y género, con porcentajes.
select		rango_edad, genero,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from (		select
case
			when edad between 19 and 21 then '19 a 21'
			when edad between 22 and 30 then '22 a 30'
			when edad between 31 and 40 then '31 a 40'
			when edad between 41 and 50 then '41 a 50'
			when edad between 51 and 60 then '51 a 60'
			when edad > 60 then 'Más de 60'
end as 		rango_edad, genero
from		tutorias
where 		edad >= 19
) as 		sub
Group by	rango_edad, genero
Order by
		Case rango_edad
			when '19 a 21' then 1
			when '22 a 30' then 2
			when '31 a 40' then 3
			when '41 a 50' then 4
			when '51 a 60' then 5
			when 'Más de 60' then 6
end,
    genero;
    
    
-- 1.7.2. Contar Tutorías por edad, (19 a 21, 22 a 30, 31 a 40, 41 a 50, 51 a 60, más de 60.) y nacionalidad, con porcentajes.
select		rango_edad, nacionalidad,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from (	select
case
		when edad between 19 and 21 then '19 a 21'
		when edad between 22 and 30 then '22 a 30'
		when edad between 31 and 40 then '31 a 40'
		when edad between 41 and 50 then '41 a 50'
		when edad between 51 and 60 then '51 a 60'
		when edad > 60 then 'Más de 60'
end as 	rango_edad, nacionalidad
from		tutorias
where	edad >= 19
) as 	sub
Group by	rango_edad, nacionalidad
Order by	case rango_edad
		when '19 a 21' then 1
		when '22 a 30' then 2
		when '31 a 40' then 3
		when '41 a 50' then 4
		when '51 a 60' then 5
		when 'Más de 60' then 6
	end,
	nacionalidad;
    
-- 1.7.3. Contar Tutorías por edad, (19 a 21, 22 a 30, 31 a 40, 41 a 50, 51 a 60, más de 60.) y provincia de residencia, con porcentajes.
select	rango_edad,	provincia_residencia,
		count(*) as cantidad_tutorias,
		round(count(*) * 100.0 / (select count(*) from  tutorias), 2) as porcentaje 
from (
	select
		case
			when edad between 19 and 21 then '19 a 21'
			when edad between 22 and 30 then '22 a 30'
			when edad between 31 and 40 then '31 a 40'
			when edad between 41 and 50 then '41 a 50'
			when edad between 51 and 60 then '51 a 60'
			when edad > 60 then 'Más de 60'
	end 
as 		rango_edad, provincia_residencia
from 	tutorias
		where edad >= 19
) as 	sub
Group by rango_edad, provincia_residencia
Order by
		Case rango_edad
			when '19 a 21' then 1
			when '22 a 30' then 2
			when '31 a 40' then 3
			when '41 a 50' then 4
			when '51 a 60' then 5
			when 'Más de 60' then 6
		end,
		provincia_residencia;


-- 1.7.4. Contar Tutorías por edad, (19 a 21, 22 a 30, 31 a 40, 41 a 50, 51 a 60, más de 60.) y nivel educativo, con porcentajes.
select	rango_edad,	nivel_educativo,
		count(*) as cantidad_tutorias,
		round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from (	
	select
	case
		when edad between 19 and 21 then '19 a 21'
		when edad between 22 and 30 then '22 a 30'
		when edad between 31 and 40 then '31 a 40'
		when edad between 41 and 50 then '41 a 50'
		when edad between 51 and 60 then '51 a 60'
		when edad > 60 then 'Más de 60'
		end as rango_edad, nivel_educativo
from 		tutorias
where 		edad >= 19
		) as sub
Group by 	rango_edad, nivel_educativo
Order by
		case rango_edad
			when '19 a 21' then 1
			when '22 a 30' then 2
			when '31 a 40' then 3
			when '41 a 50' then 4
			when '51 a 60' then 5
			when 'Más de 60' then 6
		end,
	nivel_educativo;

-- 1.8.1.Contar Tutorías por nacionalidad y género, con porcentajes.
select		nacionalidad, genero,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from		tutorias
group by	nacionalidad, genero
order by	nacionalidad, genero;

-- 1.8.2. Contar Tutorías por nacionalidad y nivel educativo, con porcentajes.
select		nacionalidad, nivel_educativo,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from		tutorias
group by	nacionalidad, nivel_educativo
order by	nacionalidad, nivel_educativo;

-- 1.8.3. Contar Tutorías por nacionalidad y provincia de residencia, con porcentajes.
select		nacionalidad, provincia_residencia,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from		tutorias
group by	nacionalidad, provincia_residencia
order by	nacionalidad, provincia_residencia;

-- 1.9.1. Contar Tutorías por nivel educativo y género, con porcentajes.
select		nivel_educativo, genero,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from		tutorias
group by	nivel_educativo, genero
order by	nivel_educativo, genero;

-- 1.9.2. Contar tutorías por nivel educativo y provincia de residencia, con porcentajes.
select		nivel_educativo, provincia_residencia,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from		tutorias
group by	nivel_educativo, provincia_residencia
order by	nivel_educativo, provincia_residencia;

-- 1.10. Contar Tutorías por género y provincia de residencia, con porcentajes.
select		genero,	provincia_residencia,
			count(*) as cantidad_tutorias,
			round(count(*) * 100.0 / (select count(*) from tutorias), 2) as porcentaje 
from		tutorias
group by	genero, provincia_residencia
order by	genero, provincia_residencia;


-- 2. EVALUACIONES

-- 2.1. Obtener la cantidad de evaluaciones
Select 		count(*) as total_evaluaciones
from 		evaluaciones;


-- 2.2. Cantidad de evaluaciones por tutorías.
select		t.id as id_tutoria, t.apellido_nombre,
			count(ev.id) as cantidad_evaluaciones
from		tutorias t
left join	evaluaciones ev on t.id = ev.id_tutorias
group by	t.id
order by	cantidad_evaluaciones desc;


-- 2.3. Cantidad de evaluaciones por año de evaluación, con porcentajes.
Select		year(fecha_evaluacion) as año,
    		count(*) as cantidad_evaluaciones
from		evaluaciones
group by 	year(fecha_evaluacion)
order by 	año;


-- 2.4. Cantidad de evaluaciones por norma evaluada, con porcentajes.
select		norma_evaluada,
			count(*) as cantidad,
			round(count(*) * 100.0 / (select count(*) from evaluaciones), 2) as porcentaje
from		evaluaciones
group by	norma_evaluada
order by	norma_evaluada;


-- 2.5. Cantidad de evaluaciones por provincia de evaluación, con porcentajes.
select		ev.provincia_evaluacion,
			count(*) as cantidad_evaluaciones,
			round(count(*) * 100.0 / (select count(*) from evaluaciones), 2) as porcentaje
from		evaluaciones ev
group by	ev.provincia_evaluacion
order by	porcentaje desc;


-- 2.6. Cantidad de evaluaciones por año evaluación y por norma evaluada, con porcentajes.
select     	year(fecha_evaluacion) as año, norma_evaluada,
			count(*) as cantidad,
			round(count(*) * 100.0 / (select count(*) from evaluaciones), 2) as porcentaje_total
from		evaluaciones
group by 	year(fecha_evaluacion), norma_evaluada
order by	año, norma_evaluada;


-- 2.6.1. Cantidad evaluaciones por año evaluación y por provincia de evaluación, con porcentajes.
select		year (fecha_evaluacion) as año, provincia_evaluacion,
    		count(*) as cantidad_evaluaciones,
			round(count(*) * 100.0 / (select count(*) from evaluaciones), 2) as porcentaje
from		 evaluaciones
group by	year(fecha_evaluacion), provincia_evaluacion
order by	año, provincia_evaluacion;


-- 2.6.2. Cantidad de evaluaciones por año de evaluación, por norma evaluada y su resultado, con porcentajes.
select		year(fecha_evaluacion) as año, norma_evaluada, resultado,
			count(*) as cantidad,
         	round(count(*) * 100.0 / (select count(*) from evaluaciones), 2) as porcentaje_total
from		evaluaciones
group by	year(fecha_evaluacion), norma_evaluada, resultado
order by	año, norma_evaluada, resultado;


-- 2.7. Cantidad  de evaluaciones por norma evaluada, por resultado, con porcentajes.
select		norma_evaluada, resultado,
			count(*) as cantidad,
			round(count(*) * 100.0 / (select count(*) from evaluaciones), 2) as porcentaje
from		evaluaciones
group by	norma_evaluada, resultado
order by	norma_evaluada,resultado;


-- 2.8. Cantidad de evaluaciones por norma evaluada y por provincia de evaluación, con porcentajes.
select		provincia_evaluacion,norma_evaluada, 
			count(*) as cantidad,
			round(count(*) * 100.0 / (select  count(*) from evaluaciones), 2) as porcentaje_total
from		evaluaciones
group by	provincia_evaluacion,norma_evaluada
order by	provincia_evaluacion,norma_evaluada;



-- 2.8.1. Cantidad de evaluaciones por norma evaluada, por provincia de evaluación, por año con porcentajes.
Select 		year(fecha_evaluacion) as año,  provincia_evaluacion, norma_evaluada,  
			count(*) as cantidad,
			round(count(*) * 100.0 / (select count(*) from evaluaciones), 2) as porcentaje_total
from		evaluaciones
group by	year(fecha_evaluacion),  norma_evaluada,  provincia_evaluacion
order by	año, provincia_evaluacion,  norma_evaluada;



-- 3. Cantidad de evaluaciones por empresa, con porcentajes.
select		e.nombre_empresa,
			count(ev.id) as cantidad,
			round(count(ev.id) * 100.0 / (select count(*) from evaluaciones), 2) as porcentaje
from		empresas e
left join	evaluaciones ev on ev.id_empresas = e.id
group by	e.nombre_empresa
order by	e.nombre_empresa;


-- 3.1. Cantidad de evaluaciones por empresa y por año, con porcentajes.
select		year(ev.fecha_evaluacion) as año,   e.nombre_empresa,
			count(*) as cantidad,
			round(count(*) * 100.0 / (select  count(*) from evaluaciones), 2) as porcentaje_total
from		evaluaciones ev
left join	empresas e on ev.id_empresas = e.id
group by	year(ev.fecha_evaluacion),   e.nombre_empresa
order by	año,   e.nombre_empresa;

											


-- 3.2. Cantidad de evaluaciones por empresa, por provincia de evaluación, con porcentajes.
select		ev.provincia_evaluacion, e.nombre_empresa, 
			count(*) as cantidad_evaluaciones,
			round(count(*) * 100.0 / (select count(*) from evaluaciones), 2) as porcentaje
from		evaluaciones ev
left join	empresas e on ev.id_empresas = e.id
group by	e.nombre_empresa, ev.provincia_evaluacion
order by	ev.provincia_evaluacion;


-- 3.3. Cantidad de evaluaciones por empresa, por norma_evaluada, por resultado, con porcentajes.
select		e.nombre_empresa, ev.norma_evaluada, ev.resultado,
			count(*) as cantidad,
			round(count(*) * 100.0 / (select count(*) fromevaluaciones), 2) as porcentaje
from		empresas e
left join	evaluaciones ev ON e.id = ev.id_empresas
group by	e.nombre_empresa, ev.norma_evaluada, ev.resultado
order by	e.nombre_empresa, ev.norma_evaluada;


